# MUSA MESSENGER DUAL — Android starter project

এটি Java-ভিত্তিক AndroidIDE/Android Studio starter project। অ্যাপটিতে:
- MUSA ব্র্যান্ডের কালো-সোনালি UI
- একাধিক অ্যাকাউন্টের নাম/লেবেল স্থানীয়ভাবে সংরক্ষণের তালিকা
- Messenger ইনস্টল থাকলে সেটি খোলার বোতাম
- Messenger ইনস্টল না থাকলে নির্দেশনা

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এই প্রজেক্ট Messenger-এর দ্বিতীয় স্বাধীন instance তৈরি করে না এবং Facebook/Messenger-এর login বা security ব্যবস্থা পরিবর্তন করে না। Android-এর সাধারণ অ্যাপ থেকে অন্য অ্যাপকে নিরাপদভাবে clone করা যায় না। একাধিক লগইনের জন্য Messenger-এর নিজস্ব account switching / Add account সুবিধা ব্যবহার করুন। লেবেলগুলো শুধু এই অ্যাপের মধ্যে নোট হিসেবে থাকে।

## AndroidIDE-তে চালানো
1. ZIP ফাইলটি extract করুন।
2. AndroidIDE থেকে `MUSA_MESSENGER_DUAL` ফোল্ডারটি Open করুন।
3. Gradle sync শেষ হতে দিন (প্রথমবার ইন্টারনেট লাগতে পারে)।
4. Build > Assemble/Build APK চালান।
5. APK ইনস্টল করে পরীক্ষা করুন।

প্রস্তাবিত: JDK 17 এবং Android Gradle Plugin 8.6.1. যদি AndroidIDE-তে এই AGP সমর্থিত না হয়, IDE-এর উপলব্ধ সংস্করণ অনুযায়ী AGP/Gradle সামঞ্জস্য করতে হবে।
