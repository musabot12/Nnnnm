package com.musa.messengerdual;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String PREFS = "musa_dual_accounts";
    private static final String KEY = "labels";
    private static final String MESSENGER = "com.facebook.orca";
    private LinearLayout list;
    private SharedPreferences prefs;
    private final int bg = Color.rgb(16,17,20);
    private final int panel = Color.rgb(29,31,37);
    private final int gold = Color.rgb(230,190,94);
    private final int white = Color.rgb(246,246,248);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
        renderAccounts();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius * getResources().getDisplayMetrics().density);
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(bg); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(shape(gold, 14));
        return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(26), dp(20), dp(24));
        scroll.addView(root);
        setContentView(scroll);

        TextView mark = text("M", 28, gold, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(shape(panel, 22));
        root.addView(mark, lp(dp(58), dp(58)));

        TextView title = text("MUSA MESSENGER DUAL", 23, white, true);
        title.setPadding(0, dp(18), 0, dp(4));
        root.addView(title);
        TextView sub = text("YOUR ACCOUNTS • YOUR CONTROL", 11, gold, true);
        root.addView(sub);

        TextView info = text("Account labels are saved on this device. Use Messenger’s own account switcher to sign in to different accounts.", 14, Color.LTGRAY, false);
        info.setPadding(dp(14), dp(14), dp(14), dp(14));
        info.setBackground(shape(panel, 16));
        LinearLayout.LayoutParams infoLp = lp(-1, -2); infoLp.topMargin = dp(22);
        root.addView(info, infoLp);

        Button add = button("+  Add account label");
        LinearLayout.LayoutParams addLp = lp(-1, dp(52)); addLp.topMargin = dp(18);
        root.addView(add, addLp);
        add.setOnClickListener(v -> showAddDialog());

        Button open = button("Open Messenger");
        LinearLayout.LayoutParams openLp = lp(-1, dp(52)); openLp.topMargin = dp(10);
        root.addView(open, openLp);
        open.setOnClickListener(v -> openMessenger());

        TextView heading = text("SAVED ACCOUNT LABELS", 12, gold, true);
        LinearLayout.LayoutParams h = lp(-1, -2); h.topMargin = dp(28); h.bottomMargin = dp(12);
        root.addView(heading, h);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list, lp(-1, -2));

        TextView foot = text("MUSA DUAL • VERSION 1.0\nThis app does not clone Messenger or bypass its login protections.", 11, Color.GRAY, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(26), 0, 0);
        root.addView(foot);
    }

    private void renderAccounts() {
        list.removeAllViews();
        Set<String> saved = prefs.getStringSet(KEY, new HashSet<>());
        ArrayList<String> labels = new ArrayList<>(saved);
        java.util.Collections.sort(labels, String.CASE_INSENSITIVE_ORDER);
        if (labels.isEmpty()) {
            TextView empty = text("No labels yet. Tap “Add account label” to create one.", 14, Color.LTGRAY, false);
            empty.setPadding(dp(14), dp(18), dp(14), dp(18));
            empty.setBackground(shape(panel, 14));
            list.addView(empty);
            return;
        }
        for (String label : labels) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(14), dp(12), dp(8), dp(12));
            card.setBackground(shape(panel, 15));
            LinearLayout.LayoutParams cp = lp(-1, -2); cp.bottomMargin = dp(9);
            list.addView(card, cp);

            TextView icon = text("M", 18, gold, true);
            icon.setGravity(Gravity.CENTER);
            icon.setBackground(shape(bg, 14));
            card.addView(icon, lp(dp(42), dp(42)));

            TextView name = text(label, 15, white, true);
            name.setPadding(dp(12), 0, dp(4), 0);
            card.addView(name, new LinearLayout.LayoutParams(0, -2, 1));

            TextView remove = text("✕", 18, Color.LTGRAY, true);
            remove.setGravity(Gravity.CENTER);
            card.addView(remove, lp(dp(42), dp(42)));
            remove.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Remove label?")
                .setMessage("Remove “" + label + "” from this app?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Remove", (d, w) -> {
                    Set<String> next = new HashSet<>(prefs.getStringSet(KEY, new HashSet<>()));
                    next.remove(label); prefs.edit().putStringSet(KEY, next).apply(); renderAccounts();
                }).show());
        }
    }

    private void showAddDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("e.g. Personal, Work, Family");
        input.setTextColor(white);
        input.setHintTextColor(Color.GRAY);
        int pad = dp(12); input.setPadding(pad,pad,pad,pad);
        new AlertDialog.Builder(this)
            .setTitle("Add account label")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", (dialog, which) -> {
                String value = input.getText().toString().trim();
                if (value.isEmpty()) { toast("Enter a label first."); return; }
                Set<String> next = new HashSet<>(prefs.getStringSet(KEY, new HashSet<>()));
                if (next.size() >= 20) { toast("Maximum 20 labels."); return; }
                next.add(value); prefs.edit().putStringSet(KEY, next).apply(); renderAccounts();
            }).show();
    }

    private void openMessenger() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(MESSENGER);
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } else {
            new AlertDialog.Builder(this)
                .setTitle("Messenger not found")
                .setMessage("Install the official Messenger app, then return here.")
                .setNegativeButton("Close", null)
                .setPositiveButton("Open Play Store", (d, w) -> {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + MESSENGER))); }
                    catch (Exception e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + MESSENGER))); }
                }).show();
        }
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
